create view AntalSpelPerPerson as
  select `GameArchiveDB1`.`KeyPeople`.`Name` AS `Name`, count(`GameArchiveDB1`.`Game`.`Name`) AS `Antal`
  from `GameArchiveDB1`.`Game`
         join `GameArchiveDB1`.`KeyPeople`
         join `GameArchiveDB1`.`hasKeyPeople`
  where ((`GameArchiveDB1`.`Game`.`Name` = `GameArchiveDB1`.`hasKeyPeople`.`GameName`) and
         (`GameArchiveDB1`.`hasKeyPeople`.`KeyPeople` = `GameArchiveDB1`.`KeyPeople`.`Name`))
  group by `GameArchiveDB1`.`KeyPeople`.`Name`;

